﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClassLibrary1.Concerete;
using RecordShopAppDAL.Context;
using RecordShopAppDAL.Interface;

namespace RecordShopAppDAL.Concrete
{
    public class AdminRepo : BaseRepo<Admin>,IAdminRepo
    {
        public AdminRepo(AppDbContext context) : base(context)
        {
        }
    }
}
