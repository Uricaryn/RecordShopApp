﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Intrinsics.X86;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1.Enum
{
    public enum Genre
    {
        Pop,
        Rock,
        Folk,
        Jazz,
        Blues,
        HeavyMetal
    }
}
